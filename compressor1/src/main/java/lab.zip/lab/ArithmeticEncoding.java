package lab;

import java.io.IOException;
import java.util.Scanner;

import static lab.Entropy.prob;
import static lab.byteReader.readBytes;

public class ArithmeticEncoding {
    public static double ae(String S, double[] P, int Max) {   //Max = 128
        int Len = S.length();
        double[] Interval = new double[2];
        double[] Cumulative = new double[Max + 1];
        for (int i = 0; i < Max; i++) {
            Cumulative[i + 1] += Cumulative[i] + P[i];
        }
        double[] IntervalPartition = new double[Max + 1];
        for (int i = 0; i < Max; i++) {
            IntervalPartition[i] = Cumulative[i];
        }
        for (int i = 0; i < Len; i++) {
            Interval[0] = IntervalPartition[S.charAt(i)];
            Interval[1] = IntervalPartition[S.charAt(i) + 1];
            for (int j = 0; j < Max; j++) {
                IntervalPartition[j] = (Interval[1] - Interval[0]) * Cumulative[j] + Interval[0];
            }
        }
        System.out.println("Borders are " + Interval[0] + ", " + Interval[1]);
        return (Interval[0] + Interval[1]) / 2;
    }

    public static void main (String[] args) throws IOException {    //тестовый (так для всех)
        Scanner in = new Scanner(System.in);
        StringBuilder Text = new StringBuilder();
        for (int i = 0; i < 1; i++) {
            Text.append("a".repeat(187)).append("b".repeat(10000));
        }
        String Text1 = "";
        double TextDone = ae(Text.toString(), prob(Text.toString(), 256, 1), 256);
        System.out.println("aeEncoded\n" + TextDone);
    }
}
