package lab;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

import static lab.byteReader.*;

public class testStringByted {
    public static void main (String[] args) throws IOException {
        System.out.print("      ");
        /*Scanner in = new Scanner(System.in);
        String filename;
        writeBytes("255s.txt", "ÿ");
        System.out.print("Введите путь до файла (utf) ");
        filename = in.nextLine();
        String Text = readBytes(filename);
        System.out.println(Text.charAt(0));
        char[] chars = readCharsFromStr(Text);
        System.out.println("chars storages:");
        for (int i = 0; i < chars.length; i++) {
            System.out.println(chars[i]);
        }
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < chars.length; i++) {
            str.append(chars[i]);
        }
        System.out.println("str (builder) storages:");
        System.out.println(str);
        int[] ints = readIntsFromStr(Text);
        System.out.println("ints storages:");
        for (int i = 0; i < ints.length; i++) {
            System.out.println(ints[i]);
        }
        System.out.println(Text);
        str = new StringBuilder();
        str.append((char)0xd9).append((char)0x86);

        System.out.println("new str (builder) storages:");
        System.out.println(str.toString().charAt(0));

        System.out.println("reading only bytes: ");
        byte[] b = readOnlyBytes(filename);
        for (int i = 0; i < b.length; i++) {
            System.out.println((char)(b[i] & 0xFF));
        }
        chars = readOnlyChars(filename);
        str = new StringBuilder();
        for (int i = 0; i < chars.length; i++) {
            str.append(chars[i]);
        }
        System.out.println("str (builder) storages:");
        System.out.println(str);
        String lastSym = str.toString();
        System.out.println(lastSym);
        System.out.println(new String(lastSym.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8));
         */
    }
}
