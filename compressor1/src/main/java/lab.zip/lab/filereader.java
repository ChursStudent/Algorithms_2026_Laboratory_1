package lab;

import java.io.FileInputStream;
import java.io.IOException;

public class filereader {
    public static String readFile(String name) {
        StringBuilder Read = new StringBuilder();
        try (FileInputStream fis = new FileInputStream(name)) {
            int byteData;
            while ((byteData = fis.read()) != -1) {
                Read.append((char)byteData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Read.toString();
    }
}
