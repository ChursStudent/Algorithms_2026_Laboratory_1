package lab;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

public class byteReader {
    public static String readBytes(String path) throws IOException {
        byte[] bytes = Files.readAllBytes(Paths.get(path));
        /*String str = new String(bytes, StandardCharsets.ISO_8859_1);
        System.out.println(str);
        System.out.println(bytes.length);
        System.out.println((char)((bytes[5] & 0xFF)*256+(bytes[6]&0xFF)));*/
        return new String(bytes, StandardCharsets.ISO_8859_1);
    }

    public static void writeBytes(String path, String text) throws IOException {   //можно и имя в раб директории и путь в диске
        Scanner in = new Scanner(System.in);
        System.out.print("Файл на английском, русском или utf-8 ? ");
        int choice = in.nextInt();
        switch(choice) {
            case 1:
                Files.writeString(Paths.get(path), new String((text.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.ISO_8859_1), StandardCharsets.ISO_8859_1);
                break;
            case 2: //надо добавить сюда переводчик из iso в 1251
                Files.writeString(Paths.get(path), new String((text.getBytes(StandardCharsets.ISO_8859_1)), "windows-1251"), Charset.forName("windows-1251"));
                break;
            case 3: //и сюда в utf
                Files.writeString(Paths.get(path), new String((text.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8), StandardCharsets.UTF_8);   //26 было просто text
                break;
            default:
                break;
        }
    }

    /*public static char[] readCharsFromStr(String text) {
        byte[] bytes = text.getBytes(StandardCharsets.ISO_8859_1);
        char[] chars = new char[bytes.length];
        for (int i = 0; i < chars.length; i++) {
            chars[i] = (char)(bytes[i] & 0xFF);
        }
        return chars;
    }

    public static String writeCharsToStr(char[] text) {
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < text.length; i++) {
            str.append(text[i]);
        }
        return str.toString();
    }

    public static int[] readIntsFromStr(String text) {
        byte[] bytes = text.getBytes(StandardCharsets.ISO_8859_1);
        int[] ints = new int[bytes.length];
        for (int i = 0; i < ints.length; i++) {
            ints[i] = bytes[i] & 0xFF;
        }
        return ints;
    }

    public static byte[] readOnlyBytes(String path) throws IOException {
        byte[] bytes = Files.readAllBytes(Paths.get(path));
        return bytes;
    }

    public static char[] readOnlyChars(String path) throws IOException {
        byte[] bytes = Files.readAllBytes(Paths.get(path));
        char[] chars = new char[bytes.length];
        for (int i = 0; i < chars.length; i++) {
            chars[i] = (char)(bytes[i] & 0xFF);
        }
        return chars;
    }*/
}
